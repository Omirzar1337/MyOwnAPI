package vista;

import static MyOwnAPI.Arithmetic.*;
import java.util.Scanner;

public class Metodes {

    public static void mostrarMenu() {

        System.out.println("***Menu Calculador***");
        System.out.println("1.- Sumar dos numeros [0 - 100]");
        System.out.println("2.- Restar dos numeros [0 - 100]");
        System.out.println("3.- Salir");

    }

    public static void main(String[] args) {
        boolean exit = false;
        Scanner sc = new Scanner(System.in);

        do {

            mostrarMenu();
            int opc = sc.nextInt();

            switch (opc) {

                case 1:
//                    int num1 = obtenerNumero("Introduce un numero entre 0 y 100");
//                    int num2 = obtenerNumero("Introduce un numero entre 0 y 100");
//                    System.out.println("La suma de estos dos numeros es: " + (num1 + num2));
                    
                    System.out.println("La suma de estos dos numeros es: " + suma());
                    break;
                case 2:
                    System.out.println("La resta de estos dos numeros es: " + resta());
                    break;
                case 3:
                    System.out.println("Gracias por utilizar la aplicacion!");
                    exit = true;
                    break;
                default:
                    System.out.println("Opcion no disponible");

            }

        } while (!exit);

    }
}
