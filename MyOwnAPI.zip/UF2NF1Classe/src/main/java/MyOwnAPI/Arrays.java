package MyOwnAPI;

public class Arrays {

    // **********Detect First Free Position**********
    public static int posLibrePrim(int[] array) { // Entry arg int array

        int posLibre = -1; // Default value -1 (This way I don't have to write extra code)

        for (int Pos = 0; Pos < array.length && posLibre == -1; Pos++) { // Iterate array with "pos" variable

            if (array[Pos] == 0) { // Checking if there's an empty value

                posLibre = Pos;

            }

        }

        return posLibre; // Return statement (int)

    }
    
    // **__**__**__**__

    public static int posLibreObj(String[] array) { // Entry arg string array

        int posLibre = -1; // Default value -1 (This way I don't have to write extra code)

        for (int Pos = 0; Pos < array.length && posLibre == -1; Pos++) { // Iterate array with "pos" variable

            if (array[Pos] == null) { // Checking if there's a null value

                posLibre = Pos;

            }

        }

        return posLibre; // Return statement (int)

    }

    // **********Check If Array Is Full**********
    public static String arrCompletoPrim(int[] array) { // Entry arg string array

        boolean comp = true; // Default value to be able to use a While
        String completo = "El array está completo"; // Default value (This way I don't have to write extra code)

        while (comp) { // While comp is true...

            for (int pos = 0; pos < array.length; pos++) { // Iterate array with "pos" variable

                if (array[pos] == 0) { // Checking if there's an empty value

                    comp = false; // Comp turns false (While breaks)
                    completo = "El array está incompleto"; // completo value changes

                }

            }

        }

        return completo; // Return statement (array)

    }
    
    // **__**__**__**__

    public static String arrCompletoObj(String[] array) { // Entry arg string array

        boolean comp = true; // Default value to be able to use a While
        String completo = "El array está completo"; // Default value (This way I don't have to write extra code)

        while (comp) { // While comp is true...

            for (int pos = 0; pos < array.length; pos++) { // Iterate array with "pos" variable

                if (array[pos] == null) { // Checking if there's a null value

                    comp = false; // Comp turns false (While breaks)
                    completo = "El array está incompleto"; // completo value changes

                }

            }

        }

        return completo; // Return statement (array)

    }
}
