package MyOwnAPI;

import static MyOwnAPI.DataIn.obtenerNumero;

public class Arithmetic {
    
    public static int suma() {

        int tamaño = obtenerNumero("Introduce el tamaño de la operacion");
        int arrayPrimer [] = new int [tamaño];
        int suma = 0;
        for (int i = 0; i < arrayPrimer.length; i++) {
            
            int num1 = obtenerNumero("Introduce un valor de 0 a 100");
            arrayPrimer[i] = num1;
            
        }
        
        for (int i = 0; i < arrayPrimer.length; i++) {
            suma += arrayPrimer[i];
        }
        
        return suma;

    }

    public static int resta() {

        int num1 = obtenerNumero("Introduce un valor de 0 a 100");
        int num2 = obtenerNumero("Introduce un valor de 0 a 100");
        int resta = num1 - num2;
        return resta;

    }
    
}
