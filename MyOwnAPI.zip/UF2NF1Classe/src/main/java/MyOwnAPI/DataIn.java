package MyOwnAPI;

import java.util.Scanner;

public class DataIn {

    public static int obtenerNumero(String mensaje) {

        Scanner input = new Scanner(System.in);
        int numero;
        do {
            System.out.println(mensaje);
            numero = input.nextInt();
        } while (numero < 0 || numero > 100);

        return numero;

    }
}
